package com.example.demotest.host;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
